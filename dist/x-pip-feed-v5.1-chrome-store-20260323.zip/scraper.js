// ── SCRAPER + PiP LAUNCHER ──
// Content script on supported feed pages.
// 1) Extracts posts, optionally translates X items, then stores source-specific feed state.
// 2) Adds a PiP button so the floating feed can be opened from the page.

const PLATFORM = (() => {
  const host = window.location.hostname;
  if (host === "x.com" || host === "twitter.com") return "x";
  if (host === "truthsocial.com") return "truth";
  return "unknown";
})();

const LOG_PREFIX = PLATFORM === "x" ? "[X PiP]" : "[PiP]";
const X_FEED_STORAGE_KEY = "tweets";
const TRUTH_FEED_STORAGE_KEY = "truthTweets";
const TRUTH_PROFILE_URL = "https://truthsocial.com/@realDonaldTrump";
const TRUTH_ACCOUNT = "realDonaldTrump";
const SCRAPE_FALLBACK_INTERVAL_MS = 500;
const SCRAPE_MUTATION_DEBOUNCE_MS = 50;
const SCRAPE_TIMEOUT_MS = 30000;
let scraperMode = false;
let scrapeIntervalId = null;
let scrapeMutationTimeoutId = null;
let scrapeObserver = null;
let scrapeInFlight = false;
let pagePiPActive = false;
const FOLLOWING_TAB_LABELS = ["following", "abonnements"];
const FOLLOWING_QUERY = "filter=follows";

console.log(LOG_PREFIX, "Content script loaded:", window.location.href);

function isContextInvalidatedError(error) {
  return !!error && /Extension context invalidated/i.test(String(error.message || error));
}

function hasValidExtensionContext() {
  try {
    return !!chrome?.runtime?.id && !!chrome?.storage?.local;
  } catch (error) {
    return false;
  }
}

function stopScrapeLoop() {
  if (scrapeIntervalId) {
    clearInterval(scrapeIntervalId);
    scrapeIntervalId = null;
  }
  if (scrapeMutationTimeoutId) {
    clearTimeout(scrapeMutationTimeoutId);
    scrapeMutationTimeoutId = null;
  }
  if (scrapeObserver) {
    scrapeObserver.disconnect();
    scrapeObserver = null;
  }
  scrapeInFlight = false;
}

function safeStorageLocalGet(keys, callback) {
  if (!hasValidExtensionContext()) {
    stopScrapeLoop();
    return false;
  }
  try {
    chrome.storage.local.get(keys, (data) => {
      void chrome.runtime.lastError;
      callback(data || {});
    });
    return true;
  } catch (error) {
    if (!isContextInvalidatedError(error)) {
      console.warn(LOG_PREFIX, "Storage read failed:", error);
    }
    stopScrapeLoop();
    return false;
  }
}

function safeStorageLocalSet(value, callback) {
  if (!hasValidExtensionContext()) {
    stopScrapeLoop();
    return false;
  }
  try {
    chrome.storage.local.set(value, () => {
      void chrome.runtime.lastError;
      if (callback) callback();
    });
    return true;
  } catch (error) {
    if (!isContextInvalidatedError(error)) {
      console.warn(LOG_PREFIX, "Storage write failed:", error);
    }
    stopScrapeLoop();
    return false;
  }
}

function safeSendRuntimeMessage(message, callback) {
  if (!hasValidExtensionContext()) {
    stopScrapeLoop();
    return false;
  }
  try {
    chrome.runtime.sendMessage(message, (response) => {
      void chrome.runtime.lastError;
      if (callback) callback(response);
    });
    return true;
  } catch (error) {
    if (!isContextInvalidatedError(error)) {
      console.warn(LOG_PREFIX, "Runtime message failed:", error);
    }
    stopScrapeLoop();
    return false;
  }
}

function normalizeText(value) {
  return (value || "").trim().toLowerCase();
}

function getItemKey(item) {
  return item.url || [
    item.source || PLATFORM,
    item.account || "",
    item.timestamp || "",
    item.text || "",
  ].join("|");
}

// ══════════════════════════════════════════════════════════════
// X SCRAPING
// ══════════════════════════════════════════════════════════════

function extractXTweets() {
  const articles = document.querySelectorAll('article[data-testid="tweet"]');
  const tweets = [];
  articles.forEach((article) => {
    try {
      let isRetweet = false;
      let retweetedBy = "";
      const socialCtx = article.querySelector('[data-testid="socialContext"]');
      if (socialCtx) {
        const ctxText = socialCtx.innerText || "";
        if (ctxText.toLowerCase().includes("repost")) {
          isRetweet = true;
          retweetedBy = ctxText.replace(/\s*reposted$/i, "").trim();
        }
      }

      let account = "";
      const links = article.querySelectorAll('a[role="link"][href^="/"]');
      for (const link of links) {
        const href = link.getAttribute("href");
        if (href && /^\/[A-Za-z0-9_]+$/.test(href)) {
          account = href.slice(1);
          break;
        }
      }

      const textElement = article.querySelector('[data-testid="tweetText"]');
      const text = textElement ? textElement.innerText : "";
      const timeElement = article.querySelector("time");
      let url = "";
      let timestamp = "";
      if (timeElement) {
        timestamp = timeElement.getAttribute("datetime") || timeElement.innerText || "";
        const timeLink = timeElement.closest("a");
        if (timeLink) url = timeLink.href;
      }

      if (text) {
        tweets.push({
          source: "x",
          account,
          text,
          url,
          isRetweet,
          retweetedBy,
          timestamp,
        });
      }
    } catch (err) {}
  });
  return tweets;
}

function isFollowingUrl() {
  return window.location.pathname === "/home" && window.location.search.includes(FOLLOWING_QUERY);
}

function getFollowingTab() {
  const tabs = Array.from(document.querySelectorAll('a[role="tab"], div[role="tab"]'));
  return tabs.find((tab) => {
    const label = normalizeText(tab.innerText || tab.textContent);
    return FOLLOWING_TAB_LABELS.some((name) => label === name || label.includes(name));
  }) || null;
}

function isFollowingSelected() {
  const tab = getFollowingTab();
  return !!tab && tab.getAttribute("aria-selected") === "true";
}

function ensureFollowingTimeline() {
  return new Promise((resolve) => {
    if (!isFollowingUrl()) {
      window.location.replace("https://x.com/home?filter=follows");
      resolve(false);
      return;
    }

    if (isFollowingSelected()) {
      resolve(true);
      return;
    }

    const deadline = Date.now() + 15000;

    const trySwitch = () => {
      const tab = getFollowingTab();
      if (!tab) {
        if (Date.now() >= deadline) {
          cleanup();
          resolve(false);
        }
        return;
      }

      if (tab.getAttribute("aria-selected") === "true") {
        cleanup();
        resolve(true);
        return;
      }

      tab.click();

      setTimeout(() => {
        if (tab.getAttribute("aria-selected") === "true" || isFollowingSelected()) {
          cleanup();
          resolve(true);
        } else if (Date.now() >= deadline) {
          cleanup();
          resolve(false);
        }
      }, 700);
    };

    const observer = new MutationObserver(() => {
      trySwitch();
    });

    const intervalId = setInterval(() => {
      trySwitch();
      if (Date.now() >= deadline) {
        cleanup();
        resolve(false);
      }
    }, 500);

    const cleanup = () => {
      observer.disconnect();
      clearInterval(intervalId);
    };

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["aria-selected"],
    });

    trySwitch();
  });
}

// ── Translation ──
const translateCache = {};

async function translateText(text, fromLang) {
  if (!text) return text;
  const key = fromLang + ":" + text.slice(0, 100);
  if (translateCache[key]) return translateCache[key];
  try {
    const url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" +
      encodeURIComponent(fromLang) + "&tl=en&dt=t&q=" + encodeURIComponent(text);
    const response = await fetch(url);
    const data = await response.json();
    let translated = "";
    if (data && data[0]) {
      data[0].forEach((part) => {
        if (part[0]) translated += part[0];
      });
    }
    if (translated && translated !== text) {
      translateCache[key] = translated;
      return translated;
    }
  } catch (e) {
    console.warn(LOG_PREFIX, "Translation failed:", e);
  }
  return text;
}

async function translateTweets(tweets) {
  let accounts = [];
  try {
    const resp = await new Promise((resolve) => {
      if (!safeSendRuntimeMessage({ action: "getSettings" }, resolve)) {
        resolve(null);
      }
    });
    accounts = resp?.translateAccounts || [];
  } catch (e) {}

  const accountMap = {};
  accounts.forEach((account) => {
    accountMap[account.username.toLowerCase().replace(/^@/, "")] = account.fromLang;
  });

  for (const tweet of tweets) {
    const lang = accountMap[tweet.account?.toLowerCase()];
    if (lang) {
      tweet.text = await translateText(tweet.text, lang);
    }
  }
  return tweets;
}

// ══════════════════════════════════════════════════════════════
// TRUTH SCRAPING
// ══════════════════════════════════════════════════════════════

function parseTruthTimestamp(relativeText) {
  const normalized = normalizeText(relativeText);
  if (!normalized) return "";
  const now = Date.now();
  if (normalized === "just now") {
    return new Date(now).toISOString();
  }

  const match = normalized.match(/^(\d+)\s*([smhdw])$/);
  if (!match) {
    return "";
  }

  const amount = parseInt(match[1], 10);
  const unit = match[2];
  const deltas = {
    s: 1000,
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
  };
  return new Date(now - (amount * deltas[unit])).toISOString();
}

function buildTruthPostUrl(postId) {
  if (/^\d+$/.test(postId)) {
    return "https://truthsocial.com/@" + TRUTH_ACCOUNT + "/posts/" + postId;
  }
  return TRUTH_PROFILE_URL + "#" + encodeURIComponent(postId || "latest");
}

function getTruthPostContainers() {
  const mirrorPosts = Array.from(document.querySelectorAll('.post-container[data-testid^="post-"], [data-testid^="post-"].post-container'));
  if (mirrorPosts.length) {
    return mirrorPosts;
  }

  const officialAnchors = Array.from(document.querySelectorAll(
    'a[href^="/@' + TRUTH_ACCOUNT + '/posts/"], a[href*="/users/' + TRUTH_ACCOUNT + '/statuses/"]'
  ));

  const containers = [];
  const seen = new Set();
  officialAnchors.forEach((anchor) => {
    const container = anchor.closest('article, [data-testid], [role="article"], div[tabindex], section');
    if (!container || seen.has(container)) {
      return;
    }
    seen.add(container);
    containers.push(container);
  });

  return containers;
}

function getTruthPostLinks() {
  const links = [];
  const seen = new Set();
  Array.from(document.querySelectorAll('a[href*="/posts/"], a[href*="/statuses/"]')).forEach((anchor) => {
    const href = anchor.getAttribute("href");
    if (!href) return;
    try {
      const resolved = new URL(href, window.location.origin).href;
      if (seen.has(resolved)) return;
      seen.add(resolved);
      links.push(resolved);
    } catch (e) {}
  });
  return links;
}

function isTruthRelativeTimeLine(line) {
  return /^(just now|\d+\s*[smhdw])$/i.test(line);
}

function isTruthMetricsLine(line) {
  return /^\d+(\.\d+)?[kmb]?$/i.test(line) || /^0?\d:\d{2}(?:\s*\/\s*0?\d:\d{2})?$/.test(line);
}

function isTruthNoiseLine(line) {
  return /^(avatar|profile header|followed by .+|follow|unfollow|truths|replies|media|show more|reply|retruth|share|like|bookmark|more)$/i.test(line);
}

function isTruthPostStart(lines, index) {
  if (lines[index] !== "Donald J. Trump") {
    return false;
  }

  const windowLines = lines.slice(index, index + 8);
  const handleIndex = windowLines.findIndex((line) => normalizeText(line) === "@" + TRUTH_ACCOUNT.toLowerCase());
  if (handleIndex === -1) {
    return false;
  }

  for (let i = handleIndex + 1; i < windowLines.length; i++) {
    if (isTruthRelativeTimeLine(windowLines[i])) {
      return true;
    }
    if (windowLines[i] === "·" && isTruthRelativeTimeLine(windowLines[i + 1] || "")) {
      return true;
    }
  }

  return false;
}

function extractTruthRelativeTimeFromLines(lines, startIndex) {
  for (let i = startIndex; i < Math.min(lines.length, startIndex + 8); i++) {
    if (isTruthRelativeTimeLine(lines[i])) {
      return { relativeText: lines[i], nextIndex: i + 1 };
    }
    if (lines[i] === "·" && isTruthRelativeTimeLine(lines[i + 1] || "")) {
      return { relativeText: lines[i + 1], nextIndex: i + 2 };
    }
  }

  return { relativeText: "", nextIndex: startIndex };
}

function buildTruthFallbackUrlFromText(text, index) {
  const key = encodeURIComponent((text || "latest").slice(0, 120));
  return TRUTH_PROFILE_URL + "#post-" + index + "-" + key;
}

function extractTruthPostsFromPageText() {
  const rawText = (document.body?.innerText || "").trim();
  if (!rawText) {
    return [];
  }

  const lines = rawText
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
  const links = getTruthPostLinks();
  const posts = [];

  for (let i = 0; i < lines.length; i++) {
    if (!isTruthPostStart(lines, i)) {
      continue;
    }

    const { relativeText, nextIndex } = extractTruthRelativeTimeFromLines(lines, i + 1);
    if (!relativeText) {
      continue;
    }

    const bodyParts = [];
    let cursor = nextIndex;
    while (cursor < lines.length) {
      const line = lines[cursor];
      if (isTruthPostStart(lines, cursor)) {
        break;
      }
      if (normalizeText(line) === "@" + TRUTH_ACCOUNT.toLowerCase()) {
        cursor++;
        continue;
      }
      if (line === "Donald J. Trump" || line === "·" || isTruthNoiseLine(line) || isTruthMetricsLine(line)) {
        cursor++;
        continue;
      }
      bodyParts.push(line);
      cursor++;
    }

    const text = bodyParts.join("\n\n").trim();
    if (!text) {
      i = cursor;
      continue;
    }

    const postIndex = posts.length;
    posts.push({
      source: "truth",
      account: TRUTH_ACCOUNT,
      text,
      url: links[postIndex] || buildTruthFallbackUrlFromText(text, postIndex),
      timestamp: parseTruthTimestamp(relativeText),
      isRetweet: false,
      retweetedBy: "",
    });

    i = cursor - 1;
  }

  return posts;
}

function extractTruthRelativeTime(contentRoot, container) {
  const spanMatch = Array.from(contentRoot.querySelectorAll("span"))
    .map((span) => (span.innerText || "").trim())
    .find((value) => value.includes("@" + TRUTH_ACCOUNT));
  if (spanMatch) {
    return spanMatch.split("·").pop()?.trim() || "";
  }

  const timeElement = container.querySelector("time");
  if (timeElement) {
    return (timeElement.innerText || timeElement.getAttribute("datetime") || "").trim();
  }

  const textMatch = (container.innerText || "").match(/\b(just now|\d+\s*[smhdw])\b/i);
  if (textMatch) {
    return textMatch[1];
  }

  return "";
}

function extractTruthTextFromGenericContainer(container) {
  const candidates = Array.from(container.querySelectorAll(
    '[data-testid="statusContent"], [data-testid="status-content"], div[lang], p, span'
  ));

  const seen = new Set();
  const parts = [];
  candidates.forEach((node) => {
    const text = (node.innerText || "").trim();
    const normalized = normalizeText(text);
    if (!text || seen.has(text)) return;
    if (normalized === "@"+ TRUTH_ACCOUNT.toLowerCase()) return;
    if (normalized === TRUTH_ACCOUNT.toLowerCase()) return;
    if (/^(reply|retruth|share|like|bookmark|more)$/i.test(text)) return;
    if (/^\d+[smhdw]$/i.test(text) || /^just now$/i.test(text)) return;
    if (text.length < 2) return;
    seen.add(text);
    parts.push(text);
  });

  return parts.join("\n\n").trim();
}

function extractTruthPostText(contentRoot) {
  if (!contentRoot) return "";
  const children = Array.from(contentRoot.children);
  const parts = [];
  children.forEach((child, index) => {
    if (index === 0 || index === children.length - 1) {
      return;
    }
    const text = (child.innerText || "").trim();
    if (text) {
      parts.push(text);
    }
  });
  return parts.join("\n\n").trim();
}

function extractTruthPosts() {
  const posts = getTruthPostContainers();
  const extractedPosts = posts.map((post) => {
    try {
      const dataTestId = post.getAttribute("data-testid") || "";
      const postId = dataTestId.replace(/^post-/, "");
      const contentRoot = post.querySelector(".flex-1") || post;
      if (!contentRoot) return null;

      const relativeText = extractTruthRelativeTime(contentRoot, post);
      const text = post.querySelector(".flex-1")
        ? extractTruthPostText(contentRoot)
        : extractTruthTextFromGenericContainer(contentRoot);
      const link = post.querySelector('a[href^="/@' + TRUTH_ACCOUNT + '/posts/"], a[href*="/users/' + TRUTH_ACCOUNT + '/statuses/"]');
      const resolvedUrl = link ? new URL(link.getAttribute("href"), window.location.origin).href : buildTruthPostUrl(postId);

      if (!text) {
        return null;
      }

      return {
        source: "truth",
        account: TRUTH_ACCOUNT,
        text,
        url: resolvedUrl,
        timestamp: parseTruthTimestamp(relativeText),
        isRetweet: false,
        retweetedBy: "",
      };
    } catch (e) {
      return null;
    }
  }).filter(Boolean);

  if (extractedPosts.length) {
    return extractedPosts;
  }

  return extractTruthPostsFromPageText();
}

// ══════════════════════════════════════════════════════════════
// SHARED STORAGE
// ══════════════════════════════════════════════════════════════

function storeItems(storageKey, items, label) {
  if (!safeStorageLocalGet([storageKey], (data) => {
    const existing = data[storageKey] || [];
    existing.forEach((item) => {
      item.isLastBatch = !!item.isNew;
      item.isNew = false;
    });

    const seen = new Set(existing.map(getItemKey));
    const newItems = items.filter((item) => {
      const key = getItemKey(item);
      if (!key || seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });

    newItems.forEach((item) => {
      item.isNew = true;
      item.isLastBatch = false;
    });

    const merged = [...newItems, ...existing].slice(0, 200);
    safeStorageLocalSet({ [storageKey]: merged }, () => {
      console.log(LOG_PREFIX, "Saved", merged.length, label, "(" + newItems.length + " new)");
    });
  })) {
    return;
  }
}

async function collectItemsForCurrentPlatform() {
  if (PLATFORM === "x") {
    if (!isFollowingSelected()) {
      const switched = await ensureFollowingTimeline();
      if (!switched || !isFollowingSelected()) {
        console.warn(LOG_PREFIX, "Waiting for Following timeline before scraping");
        return [];
      }
    }
    const tweets = extractXTweets();
    if (!tweets.length) return [];
    return translateTweets(tweets);
  }

  if (PLATFORM === "truth") {
    return extractTruthPosts();
  }

  return [];
}

function currentStorageKey() {
  return PLATFORM === "truth" ? TRUTH_FEED_STORAGE_KEY : X_FEED_STORAGE_KEY;
}

function currentItemLabel() {
  return PLATFORM === "truth" ? "truth posts" : "tweets";
}

function startScrapeLoop() {
  if (scrapeIntervalId || scrapeObserver) return;

  const deadline = Date.now() + SCRAPE_TIMEOUT_MS;
  const finishScrape = (items) => {
    stopScrapeLoop();

    if (items.length > 0) {
      storeItems(currentStorageKey(), items, currentItemLabel());
    }

    safeSendRuntimeMessage({
      action: "scrapeDone",
      count: items.length,
      source: PLATFORM,
    });
  };

  const runScrape = async () => {
    if (scrapeInFlight) return;
    if (Date.now() >= deadline) {
      finishScrape([]);
      return;
    }

    scrapeInFlight = true;

    try {
      const items = await collectItemsForCurrentPlatform();

      if (items.length > 0) {
        finishScrape(items);
      } else if (Date.now() >= deadline) {
        finishScrape([]);
      }
    } finally {
      scrapeInFlight = false;
    }
  };

  const scheduleScrape = (delay = 0) => {
    if (scrapeMutationTimeoutId) {
      return;
    }

    scrapeMutationTimeoutId = setTimeout(() => {
      scrapeMutationTimeoutId = null;
      void runScrape();
    }, delay);
  };

  scrapeObserver = new MutationObserver(() => {
    scheduleScrape(SCRAPE_MUTATION_DEBOUNCE_MS);
  });

  scrapeObserver.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true,
  });

  scrapeIntervalId = setInterval(() => {
    void runScrape();
  }, SCRAPE_FALLBACK_INTERVAL_MS);

  scheduleScrape(0);
}

// ══════════════════════════════════════════════════════════════
// PiP (one click, always-on-top, reads from chrome.storage)
// ══════════════════════════════════════════════════════════════

function setPiPButtonState(active) {
  pagePiPActive = !!active;
  const btn = document.getElementById("xpip-btn");
  if (!btn) return;
  btn.style.background = active ? "#e0245e" : "#1d9bf0";
  btn.textContent = active ? "Stop" : "PiP";
}

async function syncPiPButtonState() {
  try {
    const resp = await new Promise((resolve) => {
      if (!safeSendRuntimeMessage({ action: "getPipStatus" }, resolve)) {
        resolve(null);
      }
    });
    setPiPButtonState(!!resp?.active);
  } catch (e) {}
}

function togglePiPWindowFromPage() {
  const action = pagePiPActive ? "closePiPWindow" : "openPiPWindow";
  safeSendRuntimeMessage({ action }, (resp) => {
    if (resp?.ok === false) {
      console.warn(LOG_PREFIX, "Failed to toggle PiP window");
    }
    syncPiPButtonState();
  });
}

// ══════════════════════════════════════════════════════════════
// BUTTON
// ══════════════════════════════════════════════════════════════

function addPiPButton() {
  if (scraperMode || document.getElementById("xpip-btn") || !document.body) return;

  const btn = document.createElement("button");
  btn.id = "xpip-btn";
  btn.textContent = "PiP";
  btn.setAttribute("style", `
    position: fixed !important;
    top: 20px !important;
    right: 20px !important;
    width: 48px !important;
    height: 48px !important;
    background: #1d9bf0 !important;
    color: white !important;
    border-radius: 50% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    font-weight: 700 !important;
    font-size: 12px !important;
    cursor: pointer !important;
    z-index: 2147483647 !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.4) !important;
    font-family: -apple-system, sans-serif !important;
    border: none !important;
    padding: 0 !important;
  `);

  btn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    togglePiPWindowFromPage();
  }, true);

  document.body.appendChild(btn);
}

if (hasValidExtensionContext()) {
  chrome.runtime.onMessage.addListener((msg) => {
    if (scraperMode) return;

    if (msg.action === "pipStatusChanged") {
      setPiPButtonState(!!msg.active);
    }
    if (msg.action === "togglePiP") {
      togglePiPWindowFromPage();
    }
  });
}

async function initializeScraperTab() {
  try {
    const resp = await new Promise((resolve) => {
      if (!safeSendRuntimeMessage({ action: "isScraperTab" }, resolve)) {
        resolve(null);
      }
    });
    scraperMode = !!resp?.isScraper;
  } catch (e) {
    scraperMode = false;
  }

  if (document.body) {
    addPiPButton();
    syncPiPButtonState();
  } else {
    document.addEventListener("DOMContentLoaded", () => {
      addPiPButton();
      syncPiPButtonState();
    }, { once: true });
  }

  if (!scraperMode) {
    return;
  }

  if (PLATFORM === "x") {
    await ensureFollowingTimeline();
  }

  startScrapeLoop();
}

initializeScraperTab();
