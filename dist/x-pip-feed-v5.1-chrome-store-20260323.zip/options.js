const LANGUAGES = [
  { code: "ar", name: "Arabic" },
  { code: "zh", name: "Chinese" },
  { code: "cs", name: "Czech" },
  { code: "da", name: "Danish" },
  { code: "nl", name: "Dutch" },
  { code: "fa", name: "Farsi / Persian" },
  { code: "fi", name: "Finnish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "el", name: "Greek" },
  { code: "he", name: "Hebrew" },
  { code: "hi", name: "Hindi" },
  { code: "hu", name: "Hungarian" },
  { code: "id", name: "Indonesian" },
  { code: "it", name: "Italian" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "ms", name: "Malay" },
  { code: "no", name: "Norwegian" },
  { code: "pl", name: "Polish" },
  { code: "pt", name: "Portuguese" },
  { code: "ro", name: "Romanian" },
  { code: "ru", name: "Russian" },
  { code: "es", name: "Spanish" },
  { code: "sv", name: "Swedish" },
  { code: "th", name: "Thai" },
  { code: "tr", name: "Turkish" },
  { code: "uk", name: "Ukrainian" },
  { code: "ur", name: "Urdu" },
  { code: "vi", name: "Vietnamese" },
];

const DEFAULTS = {
  refreshInterval: 20,
  translateAccounts: [
    { username: "AJABreaking", fromLang: "ar" }
  ]
};

const list = document.getElementById("account-list");
const addBtn = document.getElementById("add-account");
const saveBtn = document.getElementById("save");
const savedMsg = document.getElementById("saved-msg");
const intervalInput = document.getElementById("interval");

function createLangSelect(selected) {
  let html = '<select class="lang-select">';
  LANGUAGES.forEach(l => {
    const sel = l.code === selected ? " selected" : "";
    html += '<option value="' + l.code + '"' + sel + '>' + l.name + '</option>';
  });
  html += '</select>';
  return html;
}

function addAccountRow(username, fromLang) {
  const row = document.createElement("div");
  row.className = "account-row";
  row.innerHTML =
    '<span style="color:#1d9bf0;font-weight:700;">@</span>' +
    '<input type="text" class="username" placeholder="username" value="' + (username || "") + '">' +
    createLangSelect(fromLang || "ar") +
    '<button class="remove-btn" title="Remove">&times;</button>';
  row.querySelector(".remove-btn").addEventListener("click", () => row.remove());
  list.appendChild(row);
}

function getFormData() {
  const accounts = [];
  list.querySelectorAll(".account-row").forEach(row => {
    const username = row.querySelector(".username").value.trim().replace(/^@/, "");
    const fromLang = row.querySelector(".lang-select").value;
    if (username) {
      accounts.push({ username, fromLang });
    }
  });
  let interval = parseInt(intervalInput.value, 10) || DEFAULTS.refreshInterval;
  if (interval < 10) interval = 10;
  if (interval > 300) interval = 300;
  return {
    refreshInterval: interval,
    translateAccounts: accounts
  };
}

// Load saved settings
chrome.storage.sync.get(["refreshInterval", "translateAccounts"], (data) => {
  const interval = data.refreshInterval || DEFAULTS.refreshInterval;
  const accounts = data.translateAccounts || DEFAULTS.translateAccounts;
  intervalInput.value = interval;
  accounts.forEach(a => addAccountRow(a.username, a.fromLang));
});

addBtn.addEventListener("click", () => addAccountRow("", "ar"));

saveBtn.addEventListener("click", () => {
  const data = getFormData();
  chrome.storage.sync.set(data, () => {
    savedMsg.classList.add("show");
    setTimeout(() => savedMsg.classList.remove("show"), 2000);
  });
});
